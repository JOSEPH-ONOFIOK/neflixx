export const HOME = '/';
export const BROWSE = '/browse';
export const SIGNUP = '/signup';
export const SIGNIN = '/signin';